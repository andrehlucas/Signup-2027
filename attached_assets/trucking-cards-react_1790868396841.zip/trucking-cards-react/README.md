# Opus Trucking pricing cards — portable React export

This package contains the Essentials and Pro cards from the current
`/special-offers-truckers` page, with their latest CTA:
**Click here to get started** (no phone icon and no trailing colon).

## Included

- `TruckingPricingCards.tsx` — reusable TypeScript/React component.
- `TruckingPricingCards.css` — standalone, namespaced CSS.
- `fonts/Inter-latin-variable.woff2` — the same Inter font asset used by the live page.
- `fonts/OFL.txt` — Inter font license.
- `LICENSE-icons.txt` — license for the embedded check/X SVG paths.
- `Example.tsx` — a minimal example.
- `preview.html` — a self-contained, interactive preview. Open it in a browser.

No Tailwind, Next.js API, Lucide, external font service, or backend is needed.
React is the only runtime dependency of the component. Your host project supplies
React/ReactDOM and its usual TypeScript/JSX build tooling.

## Install in an existing React or Next.js App Router project

1. Copy this entire folder into your project, for example:
   `src/components/trucking-cards/`.
2. Keep the CSS file and `fonts/` folder beside the component. Do not copy the
   TSX file alone: the CSS and font file are required for the matching design.
3. Import and render:

```tsx
import TruckingPricingCards from './components/trucking-cards/TruckingPricingCards';

export default function Page() {
  return <TruckingPricingCards />;
}
```

The component already imports its CSS. The `'use client'` directive makes it
usable inside a Next.js App Router page, including a server-rendered page.

### Next.js Pages Router

The Pages Router requires global CSS to be imported from `pages/_app.tsx`.
Remove the CSS import from `TruckingPricingCards.tsx`, and add this in `_app.tsx`:

```tsx
import '../components/trucking-cards/TruckingPricingCards.css';
```

Use the correct relative path for your folder layout. Import the component
normally from the page where you want to display the cards.

## Show only the two cards

```tsx
<TruckingPricingCards showBillingToggle={false} showAnnualNote={false} />
```

If you display annual pricing, keep the annual explanatory note visible, or
provide equivalent wording beside the cards.

## Set initial billing

```tsx
<TruckingPricingCards defaultBilling="annual" />
```

## Connect your own billing switch

```tsx
'use client';
import { useState } from 'react';
import TruckingPricingCards, { type Billing } from './TruckingPricingCards';

export default function Pricing() {
  const [billing, setBilling] = useState<Billing>('monthly');
  return (
    <TruckingPricingCards billing={billing} onBillingChange={setBilling} />
  );
}
```

`billing` makes the component controlled; `defaultBilling` is only an initial
value for the uncontrolled mode.

## Change the CTA destinations

The current links still dial `+1 (888) 898-9868`, just like the source page.
They do not create an account or take a payment.

```tsx
<TruckingPricingCards
  ctaHrefs={{
    essentials: '/signup?plan=essentials',
    pro: '/signup?plan=pro',
  }}
/>
```

Your destination application must implement those routes. No signup or checkout
flow is included in this visual export.

## Appearance and layout

- The original cards have a 1000px maximum combined width and a 16px gap.
- At viewport widths of 768px and above, the cards sit side-by-side; below that,
  they stack, matching the source page.
- The outer wrapper preserves the original horizontal padding (16/24/32px).
- CSS uses pixel dimensions and scoped `.otc-root` / `.otc-*` selectors to avoid
  relying on the destination project's root font size or color variables.
- The bundled font and SVG icons preserve the typography and feature markers.
- Keep the cards near their original width for the same line wrapping.
  A narrow destination container will naturally wrap text differently.
- Avoid overriding `.otc-*` selectors or applying global `!important` rules
  to their descendants. Browser/OS font rasterization can differ slightly.
- A page background is intentionally not included. The truck photo, hero,
  navigation, and footer are not part of this package.

## Exact pricing rule

Monthly: Essentials **$199**, Pro **$249**.
Annual displayed monthly equivalents: Essentials **$166**, Pro **$208**.
Annual totals: **$1,990** and **$2,490**.
The exact effective monthly figures, **$165.83** and **$207.50**, are clarified
in the annual note. Do not change the annual total to match a rounded display.

Inter is distributed under the included SIL Open Font License. The check/X
paths are derived from Lucide and retain the included license notice.