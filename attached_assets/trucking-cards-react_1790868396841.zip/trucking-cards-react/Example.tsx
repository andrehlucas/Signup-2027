import TruckingPricingCards from './TruckingPricingCards';

export default function Example() {
  return (
    <main style={{ background: '#f9fafb', padding: '48px 0', minHeight: '100vh' }}>
      <TruckingPricingCards />
    </main>
  );
}