'use client';

import { useState } from 'react';
import './TruckingPricingCards.css';

export type Billing = 'monthly' | 'annual';
export type TruckingPlanId = 'essentials' | 'pro';

export interface TruckingPricingCardsProps {
  /** Optional controlled billing value. Otherwise the component manages it. */
  billing?: Billing;
  defaultBilling?: Billing;
  onBillingChange?: (billing: Billing) => void;
  showBillingToggle?: boolean;
  showAnnualNote?: boolean;
  /** Replace either CTA destination. Defaults to the current phone link. */
  ctaHrefs?: Partial<Record<TruckingPlanId, string>>;
  className?: string;
}

const sharedSummary =
  'Business Address, Live Call Answering, Call Transferring, Callout, Toll-Free, Call Logs, Mail Receipt, Digital Mail Scanning, and Occupancy Agreement.';
const highlightedFeatures = ['Vault', 'Digital Document Storage'];
const proOnlyFeatures = ['Texting', 'Custom Business Email', 'Message Taking'];
const plans = [
  {
    id: 'essentials',
    label: 'Essentials',
    description: 'A professional business base, wherever the road takes you.',
    monthly: 199,
    annualTotal: 1990,
    meetingHours: 5,
  },
  {
    id: 'pro',
    label: 'Pro',
    description: 'More ways to stay connected, with extra room to meet.',
    monthly: 249,
    annualTotal: 2490,
    meetingHours: 10,
  },
] as const;

function FeatureIcon({ included }: { included: boolean }) {
  return (
    <span className={`otc-feature-icon${included ? '' : ' otc-feature-icon--excluded'}`}>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="10"
        height="10"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        {included ? <path d="m20 6-11 11-5-5" /> : (
          <>
            <path d="M18 6 6 18" />
            <path d="m6 6 12 12" />
          </>
        )}
      </svg>
    </span>
  );
}

function Feature({ label, included = true }: { label: string; included?: boolean }) {
  return (
    <li className={`otc-feature${included ? '' : ' otc-feature--excluded'}`}>
      <FeatureIcon included={included} />
      <span className="otc-feature-text">
        {!included && <span className="otc-sr-only">Not included: </span>}
        {label}
      </span>
    </li>
  );
}

export default function TruckingPricingCards({
  billing: controlledBilling,
  defaultBilling = 'monthly',
  onBillingChange,
  showBillingToggle = true,
  showAnnualNote = true,
  ctaHrefs,
  className = '',
}: TruckingPricingCardsProps) {
  const [internalBilling, setInternalBilling] = useState<Billing>(defaultBilling);
  const billing = controlledBilling ?? internalBilling;

  function changeBilling(next: Billing) {
    if (controlledBilling === undefined) setInternalBilling(next);
    onBillingChange?.(next);
  }

  return (
    <section className={`otc-root ${className}`.trim()} aria-label="Opus Trucking plans">
      {showBillingToggle && (
        <div className="otc-billing">
          <div className="otc-billing-group" role="group" aria-label="Billing frequency">
            <button
              className="otc-billing-button"
              type="button"
              aria-pressed={billing === 'monthly'}
              onClick={() => changeBilling('monthly')}
              data-testid="button-trucking-monthly"
            >
              Monthly Billing
            </button>
            <button
              className="otc-billing-button"
              type="button"
              aria-pressed={billing === 'annual'}
              onClick={() => changeBilling('annual')}
              data-testid="button-trucking-annual"
            >
              Annual Billing
              <span className="otc-saving-badge">Save over 16%</span>
            </button>
          </div>
          <p className="otc-billing-note">Pay for 10 months up front, get 12 months of service.</p>
        </div>
      )}

      <div className="otc-grid">
        {plans.map((plan) => {
          const href = ctaHrefs?.[plan.id] ?? 'tel:+18888989868';
          return (
            <article className="otc-card" key={plan.id} data-testid={`card-trucking-${plan.id}`}>
              <div className="otc-card-top">
                <h2 className="otc-title">
                  Opus Trucking<br />
                  <span className={`otc-plan-label otc-plan-label--${plan.id}`}>{plan.label}</span>
                </h2>
                <p className="otc-description">{plan.description}</p>
                <div className="otc-pricing" aria-live="polite">
                  <div className="otc-price-row">
                    <span className="otc-price" data-testid={`price-trucking-${plan.id}`}>
                      ${billing === 'monthly' ? plan.monthly : Math.round(plan.annualTotal / 12)}
                    </span>
                    <span className="otc-price-unit">/ mo</span>
                  </div>
                  {billing === 'annual' ? (
                    <div className="otc-annual-details">
                      <p className="otc-annual-promo">2 months free when paid annually</p>
                      <p className="otc-annual-total">
                        ${plan.annualTotal.toLocaleString('en-US')} due for the year · save ${plan.monthly * 2}
                      </p>
                    </div>
                  ) : (
                    <p className="otc-monthly-note">Or pay annually and get 2 months free</p>
                  )}
                </div>
                <a
                  className="otc-cta"
                  href={href}
                  aria-label={href.startsWith('tel:')
                    ? `Call Opus about Opus Trucking ${plan.label} with ${billing} billing`
                    : `Get started with Opus Trucking ${plan.label} with ${billing} billing`}
                  data-testid={`button-trucking-${plan.id}`}
                >
                  Click here to get started
                </a>
              </div>
              <div className="otc-card-features">
                <p className="otc-features-heading">What&apos;s included</p>
                <p className="otc-summary">{sharedSummary}</p>
                <ul className="otc-feature-list">
                  <Feature label={`${plan.meetingHours} Hours Meeting Room Access per month`} />
                  {highlightedFeatures.map((feature) => <Feature key={feature} label={feature} />)}
                  {proOnlyFeatures.map((feature) => (
                    <Feature key={feature} label={feature} included={plan.id === 'pro'} />
                  ))}
                </ul>
              </div>
            </article>
          );
        })}
      </div>

      {showAnnualNote && (
        <p className="otc-annual-note">
          Annual prices are charged in full up front. Monthly equivalents are rounded for display; Essentials is $165.83/mo and Pro is $207.50/mo based on 10 monthly payments for 12 months of service.
        </p>
      )}
    </section>
  );
}