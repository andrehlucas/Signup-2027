'use client';

import { useState } from 'react';
import { Check, X } from 'lucide-react';
import { Footer } from '@/app/components/Footer';

type Billing = 'monthly' | 'annual';

const sharedFeatures = [
  'Business Address',
  'Live Call Answering',
  'Call Transferring',
  'Callout',
  'Toll-Free',
  'Call Logs',
  'Vault',
  'Digital Document Storage',
  'Mail Receipt',
  'Digital Mail Scanning',
  'Occupancy Agreement',
];

const highlightedSharedFeatures = ['Vault', 'Digital Document Storage'];
const proOnlyFeatures = ['Texting', 'Custom Business Email', 'Message Taking'];
const summarizedFeatures = sharedFeatures.filter((feature) => !highlightedSharedFeatures.includes(feature));
const sharedFeaturesSummary = `${summarizedFeatures.slice(0, -1).join(', ')}, and ${summarizedFeatures.at(-1)}.`;

const plans = [
  {
    id: 'essentials',
    name: 'Opus Trucking Essentials',
    label: 'Essentials',
    description: 'A professional business base, wherever the road takes you.',
    monthly: 199,
    annualTotal: 1990,
    meetingHours: 5,
    extras: [],
  },
  {
    id: 'pro',
    name: 'Opus Trucking Pro',
    label: 'Pro',
    description: 'More ways to stay connected, with extra room to meet.',
    monthly: 249,
    annualTotal: 2490,
    meetingHours: 10,
    extras: ['Texting', 'Custom Business Email', 'Message Taking'],
  },
] as const;

export default function TruckingOffers() {
  const [billing, setBilling] = useState<Billing>('monthly');

  return (
    <main
      className="relative isolate min-h-screen overflow-hidden bg-[radial-gradient(circle_at_top,rgba(224,242,254,0.6)_0%,rgba(249,250,251,1)_45%)] pt-[72px] lg:pt-[104px]"
      data-testid="page-special-offers-truckers"
    >
      <div className="pointer-events-none absolute inset-x-0 top-[72px] z-0 h-[660px] lg:top-[104px]" aria-hidden="true">
        <img
          src="/images/roadsidehero-fullbleed-hero.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover object-[76%_72%] md:object-[76%_70%]"
        />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              'linear-gradient(180deg, rgba(242,248,251,0.48) 0%, rgba(242,248,251,0.34) 52%, rgba(242,248,251,0.72) 100%), linear-gradient(90deg, rgba(242,248,251,0.56) 0%, rgba(242,248,251,0.24) 52%, rgba(242,248,251,0.08) 100%), radial-gradient(ellipse 72% 70% at 50% 43%, rgba(246,250,252,0.72) 0%, rgba(246,250,252,0) 100%)',
          }}
        />
        <div className="absolute inset-x-0 bottom-0 h-[300px] bg-gradient-to-b from-transparent via-[#f5f9fb]/70 to-[#f9fafb]" />
      </div>

      <section className="relative z-10 mx-auto max-w-[1120px] px-4 pb-8 pt-12 sm:px-6 lg:px-8 lg:pb-10 lg:pt-16">
        <div className="mx-auto max-w-[760px] text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.16em] text-[#026aa2]">
            Built for the road
          </p>
          <h1 className="text-4xl font-extrabold leading-[1.1] tracking-tight text-[#101828] sm:text-5xl lg:text-6xl">
            Special Offers for{' '}
            <span className="bg-gradient-to-r from-[#36bffa] to-[#026aa2] bg-clip-text text-transparent">
              Truckers
            </span>
          </h1>
          <p className="mx-auto mt-5 max-w-[620px] text-base leading-relaxed text-[#475467] sm:text-lg">
            Run your business from anywhere. Compare two complete bundles for calls, mail, documents, and a professional place to meet.
          </p>
        </div>

        <div className="mt-9 flex flex-col items-center gap-2">
          <div
            role="group"
            aria-label="Billing frequency"
            className="inline-flex max-w-full rounded-xl border border-[#d0e8f4] bg-[#f2f9fc] p-1 shadow-[0_4px_12px_rgba(16,24,40,0.09)]"
          >
            <button
              type="button"
              onClick={() => setBilling('monthly')}
              aria-pressed={billing === 'monthly'}
              className={`min-h-11 rounded-lg px-4 text-sm font-semibold transition-colors sm:px-6 ${
                billing === 'monthly'
                  ? 'border border-[#81c4e2] bg-white text-[#026aa2] shadow-sm'
                  : 'border border-transparent text-[#475467] hover:text-[#026aa2]'
              } focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#026aa2]`}
              data-testid="button-trucking-monthly"
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setBilling('annual')}
              aria-pressed={billing === 'annual'}
              className={`relative min-h-11 rounded-lg px-4 text-sm font-semibold transition-colors sm:px-6 ${
                billing === 'annual'
                  ? 'border border-[#81c4e2] bg-white text-[#026aa2] shadow-sm'
                  : 'border border-transparent text-[#475467] hover:text-[#026aa2]'
              } focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#026aa2]`}
              data-testid="button-trucking-annual"
            >
              Annual Billing
              <span className="absolute -right-2 -top-3 whitespace-nowrap rounded-full border-2 border-[#f2f9fc] bg-[#026aa2] px-2.5 py-1 text-[11px] font-bold leading-none tracking-wide text-white shadow-[0_3px_10px_rgba(2,106,162,0.18)]">
                Save over 16%
              </span>
            </button>
          </div>
          <p className="text-center text-sm font-medium text-[#026aa2]">
            Pay for 10 months up front, get 12 months of service.
          </p>
        </div>
      </section>

      <section className="relative z-10 mx-auto max-w-[1120px] px-4 pb-20 sm:px-6 lg:px-8">
        <div className="mx-auto mt-8 grid max-w-[1000px] grid-cols-1 items-stretch gap-4 md:grid-cols-2">
          {plans.map((plan) => (
            <article
              key={plan.id}
              className="flex min-w-0 flex-col overflow-hidden rounded-[30px] border border-[var(--gray-200)] bg-white shadow-[0_20px_40px_-16px_rgba(16,24,40,0.12)] transition-[transform,box-shadow] duration-[250ms] hover:-translate-y-[6px] hover:shadow-[0_16px_32px_-8px_rgba(2,106,162,0.25)] motion-reduce:transform-none"
              data-testid={`card-trucking-${plan.id}`}
            >
              <div className="flex flex-col px-8 pb-5 pt-5">
                <h2 className="min-h-[3.5rem] text-2xl font-extrabold leading-snug tracking-tight text-[var(--gray-900)]">
                  Opus Trucking
                  <br />
                  <span className={plan.id === 'pro' ? 'text-[var(--blue-light700)]' : 'text-[var(--blue-light400)]'}>
                    {plan.label}
                  </span>
                </h2>
                <p className="mt-2 min-h-8 text-sm leading-relaxed text-[var(--gray-500)]">
                  {plan.description}
                </p>

                <div className="mt-4" aria-live="polite">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-[2.5rem] font-extrabold leading-none tracking-tight text-[var(--gray-900)]" data-testid={`price-trucking-${plan.id}`}>
                      {billing === 'monthly' ? `$${plan.monthly}` : `$${Math.round(plan.annualTotal / 12)}`}
                    </span>
                    <span className="text-base font-medium text-[var(--gray-500)]">/ mo</span>
                  </div>
                  {billing === 'annual' ? (
                    <div className="mt-1 text-sm leading-5">
                      <p className="font-semibold text-[#067647]">2 months free when paid annually</p>
                      <p className="text-[var(--gray-500)]">
                        ${plan.annualTotal.toLocaleString('en-US')} due for the year · save ${plan.monthly * 2}
                      </p>
                    </div>
                  ) : (
                    <p className="mt-1 text-sm text-[var(--gray-500)]">Or pay annually and get 2 months free</p>
                  )}
                </div>

                <a
                  href="tel:+18888989868"
                  aria-label={`Call Opus about ${plan.name} with ${billing} billing`}
                  className="mt-5 flex h-[52px] w-full items-center justify-center rounded-2xl border border-[#36bff9] bg-[linear-gradient(180deg,rgba(66,197,251,1)_0%,rgba(3,137,209,1)_100%)] text-base font-bold text-white shadow-[0_8px_20px_rgba(54,191,250,0.4)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[0_10px_26px_rgba(54,191,250,0.55)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#026aa2] motion-reduce:transform-none"
                  data-testid={`button-trucking-${plan.id}`}
                >
                  Click here to get started
                </a>
              </div>

              <div className="flex-1 border-t border-[var(--gray-100)] bg-[#fbfbfc] px-6 pb-6 pt-5">
                <p className="mb-3 text-[10px] font-bold uppercase tracking-wider text-[var(--gray-400)]">
                  What&apos;s included
                </p>
                <p className="text-xs leading-relaxed text-[var(--gray-500)]">{sharedFeaturesSummary}</p>
                <ul className="mt-4 space-y-3">
                  <li className="flex items-start gap-2.5 text-xs">
                    <span className="grid size-[18px] shrink-0 place-content-center rounded-full bg-[var(--blue-light400)]">
                      <Check className="size-2.5 text-white" strokeWidth={3} aria-hidden="true" />
                    </span>
                    <span className="font-medium text-[var(--gray-700)]">
                      {plan.meetingHours} Hours Meeting Room Access per month
                    </span>
                  </li>
                  {highlightedSharedFeatures.map((feature) => (
                    <li key={feature} className="flex items-start gap-2.5 text-xs">
                      <span className="grid size-[18px] shrink-0 place-content-center rounded-full bg-[var(--blue-light400)]">
                        <Check className="size-2.5 text-white" strokeWidth={3} aria-hidden="true" />
                      </span>
                      <span className="font-medium text-[var(--gray-700)]">{feature}</span>
                    </li>
                  ))}
                  {plan.id === 'essentials'
                    ? proOnlyFeatures.map((feature) => (
                        <li key={feature} className="flex items-start gap-2.5 text-xs">
                          <span className="grid size-[18px] shrink-0 place-content-center rounded-full bg-[var(--gray-200)]">
                            <X className="size-2.5 text-[var(--gray-400)]" strokeWidth={3} aria-hidden="true" />
                          </span>
                          <span className="font-medium text-[var(--gray-400)]">
                            <span className="sr-only">Not included: </span>
                            {feature}
                          </span>
                        </li>
                      ))
                    : plan.extras.map((feature) => (
                        <li key={feature} className="flex items-start gap-2.5 text-xs">
                          <span className="grid size-[18px] shrink-0 place-content-center rounded-full bg-[var(--blue-light400)]">
                            <Check className="size-2.5 text-white" strokeWidth={3} aria-hidden="true" />
                          </span>
                          <span className="font-medium text-[var(--gray-700)]">{feature}</span>
                        </li>
                      ))}
                </ul>
              </div>
            </article>
          ))}
        </div>
        <p className="mx-auto mt-6 max-w-[760px] text-center text-xs leading-relaxed text-[#667085]">
          Annual prices are charged in full up front. Monthly equivalents are rounded for display; Essentials is $165.83/mo and Pro is $207.50/mo based on 10 monthly payments for 12 months of service.
        </p>
      </section>
      <Footer />
    </main>
  );
}