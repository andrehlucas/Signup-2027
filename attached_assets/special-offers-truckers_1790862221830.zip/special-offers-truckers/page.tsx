import type { Metadata } from 'next';
import TruckingOffers from './TruckingOffers';

export const metadata: Metadata = {
  title: 'Trucking Plans | Opus Virtual Offices',
  description: 'Compare Opus Trucking Essentials and Pro plans, with business address, live call answering, mail services, and meeting room access.',
};

export default function TruckingOffersPage() {
  return <TruckingOffers />;
}